#pragma once
#include <linux/uinput.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <cstring>
#include <cmath>

int uinput_fd = -1;

void InitVirtualTouch(int screenWidth, int screenHeight) {
    uinput_fd = open("/dev/uinput", O_WRONLY | O_NONBLOCK);
    if (uinput_fd < 0) return;

    ioctl(uinput_fd, UI_SET_EVBIT, EV_ABS);
    ioctl(uinput_fd, UI_SET_ABSBIT, ABS_MT_POSITION_X);
    ioctl(uinput_fd, UI_SET_ABSBIT, ABS_MT_POSITION_Y);
    ioctl(uinput_fd, UI_SET_ABSBIT, ABS_MT_TRACKING_ID);
    ioctl(uinput_fd, UI_SET_EVBIT, EV_KEY);
    ioctl(uinput_fd, UI_SET_KEYBIT, BTN_TOUCH);

    struct uinput_user_dev uidev;
    memset(&uidev, 0, sizeof(uidev));
    snprintf(uidev.name, UINPUT_MAX_NAME_SIZE, "kzin_virtual_touch");
    uidev.id.bustype = BUS_USB;
    uidev.id.vendor = 0x1234;
    uidev.id.product = 0x5678;
    uidev.id.version = 1;

    uidev.absmin[ABS_MT_POSITION_X] = 0;
    uidev.absmax[ABS_MT_POSITION_X] = screenWidth;
    uidev.absmin[ABS_MT_POSITION_Y] = 0;
    uidev.absmax[ABS_MT_POSITION_Y] = screenHeight;

    write(uinput_fd, &uidev, sizeof(uidev));
    ioctl(uinput_fd, UI_DEV_CREATE);
}

void EmitEvent(int type, int code, int value) {
    struct input_event ev;
    memset(&ev, 0, sizeof(ev));
    ev.type = type;
    ev.code = code;
    ev.value = value;
    write(uinput_fd, &ev, sizeof(ev));
}

void SimulateDrag(float startX, float startY, float endX, float endY) {
    if (uinput_fd < 0) return;

    EmitEvent(EV_ABS, ABS_MT_TRACKING_ID, 1);
    EmitEvent(EV_KEY, BTN_TOUCH, 1);

    EmitEvent(EV_ABS, ABS_MT_POSITION_X, (int)startX);
    EmitEvent(EV_ABS, ABS_MT_POSITION_Y, (int)startY);
    EmitEvent(EV_SYN, SYN_REPORT, 0);
    usleep(10000); 

    EmitEvent(EV_ABS, ABS_MT_POSITION_X, (int)endX);
    EmitEvent(EV_ABS, ABS_MT_POSITION_Y, (int)endY);
    EmitEvent(EV_SYN, SYN_REPORT, 0);
    usleep(10000);

    EmitEvent(EV_KEY, BTN_TOUCH, 0);
    EmitEvent(EV_ABS, ABS_MT_TRACKING_ID, -1);
    EmitEvent(EV_SYN, SYN_REPORT, 0);
}