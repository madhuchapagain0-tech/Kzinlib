#pragma once
#include <cstdint>

namespace Offsets {
    constexpr uintptr_t GameFacade        = 0xAD68E18;
    constexpr uintptr_t GameFacade_P2     = 0xB8;
    constexpr uintptr_t BaseGame_Match    = 0x90;
    constexpr uintptr_t BaseGame_Timer    = 0x20;
    constexpr uintptr_t Match_PlayerDict  = 0xC0;
    constexpr uintptr_t Match_LocalPlayer = 0xD8;
    constexpr uintptr_t Dict_Entries      = 0x18;
    constexpr uintptr_t Dict_Count        = 0x20;
    constexpr uintptr_t Dict_ArrayHeader  = 0x20;
    constexpr uintptr_t Dict_EntryStride  = 0x18;
    constexpr uintptr_t Dict_EntryValue   = 0x10;
    constexpr uintptr_t Player_Rotation   = 0xA0;
    constexpr uintptr_t Player_HeadTF     = 0x6A8;
    constexpr uintptr_t Player_FootTF     = 0x6D0;
    constexpr uintptr_t Player_Camera     = 0x30;
    constexpr uintptr_t Player_IsFiring   = 0x850;
    constexpr uintptr_t Player_HP         = 0x18;
    constexpr uintptr_t Player_IsDead     = 0x7C;
    constexpr uintptr_t Player_Avatar     = 0x778;
    constexpr uintptr_t Player_HedColider = 0x740;
    constexpr uintptr_t Player_ColWrite   = 0x80;
    constexpr uintptr_t Player_DeathInfo  = 0x24C0;
    constexpr uintptr_t Player_IsBot      = 0x4A8;
    constexpr uintptr_t Player_Name       = 0x498;
    constexpr uintptr_t Avatar_Uma        = 0x138;
    constexpr uintptr_t Uma_Visible       = 0x101;
    constexpr uintptr_t Uma_Data          = 0x28;
    constexpr uintptr_t UmaData_Skip      = 0x81;
    constexpr uintptr_t Camera_Follow     = 0x698;
    constexpr uintptr_t Camera_IntPtr     = 0x10;
    constexpr uintptr_t Camera_Matrix     = 0x100;
    constexpr uintptr_t HP_List           = 0x10;
    constexpr uintptr_t HP_Entry          = 0x20;
    constexpr uintptr_t HP_Value          = 0x18;
}