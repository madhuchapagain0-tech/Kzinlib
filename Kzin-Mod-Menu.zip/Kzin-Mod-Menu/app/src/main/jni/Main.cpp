#include <jni.h>
#include <unistd.h>
#include <pthread.h>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <fstream>

#include "imgui.h"
#include "imgui_internal.h"
#include "offsets.h"
#include "touch.h"

// 🛡️ ANTI-DEBUG
bool isDebuggerConnected() {
    std::ifstream status_file("/proc/self/status");
    std::string line;
    while (std::getline(status_file, line)) {
        if (line.find("TracerPid:") != std::string::npos) {
            int tracer_pid = atoi(line.substr(10).c_str());
            if (tracer_pid > 0) return true;
        }
    }
    return false;
}

std::string GetExpiryDate() {
    std::ifstream file("/data/local/tmp/kzin_expiry.txt");
    std::string expiry;
    if (file.is_open()) {
        std::getline(file, expiry);
        file.close();
    }
    return expiry.empty() ? "Lifetime / VIP" : expiry;
}

uintptr_t get_module_base(const char* module_name) {
    uintptr_t base = 0;
    FILE *fp = fopen("/proc/self/maps", "r");
    if (fp != nullptr) {
        char line[512];
        while (fgets(line, sizeof(line), fp)) {
            if (strstr(line, module_name)) {
                base = strtoul(line, nullptr, 16);
                break;
            }
        }
        fclose(fp);
    }
    return base;
}

struct Vector2 { float x, y; };
struct Vector3 { float x, y, z; };
struct Matrix4x4 { float m[4][4]; };

bool silentAim = false; 
bool dragHeadshot = false; 
float aimFov = 150.0f;

bool espBox = false;
bool espLine = false;
bool espName = false;
bool espHealth = false;
bool espDistance = false;

bool menuVisible = true;
int screenWidth = 0;
int screenHeight = 0;
uintptr_t libBase = 0;

template <typename T>
T Read(uintptr_t address) {
    if (address < 0x1000) return T{};
    return *reinterpret_cast<T*>(address);
}

std::string ReadString(uintptr_t address) {
    if (address < 0x1000) return "Bot";
    int length = Read<int>(address + 0x10);
    if (length < 1 || length > 30) return "Bot";
    uintptr_t strAddr = address + 0x14;
    std::string result = "";
    for (int i = 0; i < length; i++) {
        uint16_t character = Read<uint16_t>(strAddr + (i * 2));
        result += (char)character;
    }
    return result;
}

bool WorldToScreen(Vector3 pos, Vector2* screen, Matrix4x4 matrix) {
    float w = matrix.m[3][0] * pos.x + matrix.m[3][1] * pos.y + matrix.m[3][2] * pos.z + matrix.m[3][3];
    if (w < 0.01f) return false;
    float x = matrix.m[0][0] * pos.x + matrix.m[0][1] * pos.y + matrix.m[0][2] * pos.z + matrix.m[0][3];
    float y = matrix.m[1][0] * pos.x + matrix.m[1][1] * pos.y + matrix.m[1][2] * pos.z + matrix.m[1][3];
    screen->x = (screenWidth / 2.0f) + (screenWidth / 2.0f) * (x / w);
    screen->y = (screenHeight / 2.0f) - (screenHeight / 2.0f) * (y / w);
    return true;
}

void* hackThread(void*) {
    if (isDebuggerConnected()) return nullptr;

    do {
        libBase = get_module_base("libil2cpp.so");
        sleep(1);
    } while (libBase == 0);

    ImGuiIO& io = ImGui::GetIO();
    screenWidth = io.DisplaySize.x;
    screenHeight = io.DisplaySize.y;

    InitVirtualTouch(screenWidth, screenHeight);

    while (true) {
        if (isDebuggerConnected()) break; 

        if (silentAim || dragHeadshot || espBox || espLine) {
            uintptr_t gameFacade = libBase + Offsets::GameFacade;
            uintptr_t facadeP2 = Read<uintptr_t>(gameFacade + Offsets::GameFacade_P2);
            uintptr_t match = Read<uintptr_t>(facadeP2 + Offsets::BaseGame_Match);
            
            if (match != 0) {
                uintptr_t localPlayer = Read<uintptr_t>(match + Offsets::Match_LocalPlayer);
                if (localPlayer != 0) {
                    uintptr_t localCamera = Read<uintptr_t>(localPlayer + Offsets::Player_Camera);
                    bool isFiring = Read<bool>(localPlayer + Offsets::Player_IsFiring);
                    
                    if (localCamera != 0) {
                        Matrix4x4 viewMatrix = Read<Matrix4x4>(localCamera + Offsets::Camera_Matrix);
                        uintptr_t playerDict = Read<uintptr_t>(match + Offsets::Match_PlayerDict);
                        Vector3 localPos = Read<Vector3>(localPlayer + 0x38); 

                        if (playerDict != 0) {
                            uintptr_t entries = Read<uintptr_t>(playerDict + Offsets::Dict_Entries);
                            int count = Read<int>(playerDict + Offsets::Dict_Count);

                            if (entries != 0 && count > 0 && count < 50) {
                                Vector2 bestTarget = { -1, -1 };
                                float closestDist = aimFov;

                                for (int i = 0; i < count; i++) {
                                    uintptr_t entry = entries + (i * Offsets::Dict_EntryStride);
                                    uintptr_t player = Read<uintptr_t>(entry + Offsets::Dict_EntryValue);

                                    if (player != 0 && player != localPlayer) {
                                        bool isDead = Read<bool>(player + Offsets::Player_IsDead);
                                        float hp = Read<float>(player + Offsets::Player_HP);

                                        if (!isDead && hp > 0 && hp <= 200) {
                                            uintptr_t headTF = Read<uintptr_t>(player + Offsets::Player_HeadTF);
                                            if (headTF != 0) {
                                                Vector3 headPos = Read<Vector3>(headTF + 0x38); 
                                                Vector2 screenHead;
                                                
                                                if (WorldToScreen(headPos, &screenHead, viewMatrix)) {
                                                    if (espBox) {
                                                        ImGui::GetBackgroundDrawList()->AddRect(
                                                            ImVec2(screenHead.x - 40, screenHead.y - 40),
                                                            ImVec2(screenHead.x + 40, screenHead.y + 80),
                                                            IM_COL32(0, 240, 255, 255), 0, 0, 1.5f);
                                                    }
                                                    if (espLine) {
                                                        ImGui::GetBackgroundDrawList()->AddLine(
                                                            ImVec2(screenWidth / 2, 0), 
                                                            ImVec2(screenHead.x, screenHead.y), 
                                                            IM_COL32(157, 0, 255, 200), 1.5f);
                                                    }
                                                    if (espName) {
                                                        uintptr_t namePtr = Read<uintptr_t>(player + Offsets::Player_Name);
                                                        std::string name = ReadString(namePtr);
                                                        ImGui::GetBackgroundDrawList()->AddText(
                                                            ImVec2(screenHead.x - 20, screenHead.y - 60), 
                                                            IM_COL32(255, 255, 255, 255), name.c_str());
                                                    }
                                                    if (espDistance) {
                                                        float dist = sqrt(pow(headPos.x - localPos.x, 2) + pow(headPos.y - localPos.y, 2) + pow(headPos.z - localPos.z, 2));
                                                        char distStr[32];
                                                        sprintf(distStr, "[%.0fm]", dist);
                                                        ImGui::GetBackgroundDrawList()->AddText(
                                                            ImVec2(screenHead.x - 15, screenHead.y + 85), 
                                                            IM_COL32(255, 200, 0, 255), distStr);
                                                    }
                                                    if (espHealth) {
                                                        float hpPct = hp / 200.0f;
                                                        if (hpPct > 1.0f) hpPct = 1.0f;
                                                        ImU32 healthColor = IM_COL32(255 * (1 - hpPct), 255 * hpPct, 0, 255);
                                                        ImGui::GetBackgroundDrawList()->AddRectFilled(ImVec2(screenHead.x - 45, screenHead.y - 45), ImVec2(screenHead.x - 40, screenHead.y + 85), IM_COL32(0, 0, 0, 150));
                                                        ImGui::GetBackgroundDrawList()->AddRectFilled(ImVec2(screenHead.x - 44, screenHead.y + 84 - (128 * hpPct)), ImVec2(screenHead.x - 41, screenHead.y + 84), healthColor);
                                                    }

                                                    if (silentAim || dragHeadshot) {
                                                        float distToCrosshair = sqrt(pow(screenHead.x - (screenWidth/2), 2) + pow(screenHead.y - (screenHeight/2), 2));
                                                        if (distToCrosshair < closestDist) {
                                                            closestDist = distToCrosshair;
                                                            bestTarget = screenHead;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                
                                if (bestTarget.x != -1) {
                                    if (silentAim && isFiring) {
                                        SimulateDrag(screenWidth / 2, screenHeight / 2, bestTarget.x, bestTarget.y);
                                    } else if (dragHeadshot) {
                                        SimulateDrag(screenWidth / 2, screenHeight / 2, bestTarget.x, bestTarget.y);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            
            if ((silentAim || dragHeadshot) && aimFov > 0) {
                ImGui::GetBackgroundDrawList()->AddCircle(ImVec2(screenWidth / 2, screenHeight / 2), aimFov, IM_COL32(157, 0, 255, 100), 100, 1.0f);
            }
        }
        usleep(15000); 
    }
    return nullptr;
}

void SetupPremiumStyle() {
    ImGuiStyle& style = ImGui::GetStyle();
    ImVec4* colors = style.Colors;

    style.WindowRounding    = 12.0f;
    style.ChildRounding     = 10.0f;
    style.FrameRounding     = 6.0f;
    style.WindowPadding     = ImVec2(15, 15);
    style.FramePadding      = ImVec2(10, 6);
    style.ItemSpacing       = ImVec2(10, 10);

    colors[ImGuiCol_WindowBg]              = ImVec4(0.04f, 0.04f, 0.06f, 0.94f); 
    colors[ImGuiCol_Border]                = ImVec4(0.20f, 0.20f, 0.30f, 0.50f);
    colors[ImGuiCol_FrameBg]               = ImVec4(0.08f, 0.08f, 0.12f, 1.00f);
    colors[ImGuiCol_FrameBgHovered]        = ImVec4(0.15f, 0.15f, 0.25f, 1.00f);
    colors[ImGuiCol_TitleBg]               = ImVec4(0.04f, 0.04f, 0.06f, 1.00f);
    colors[ImGuiCol_TitleBgActive]         = ImVec4(0.00f, 0.94f, 1.00f, 1.00f); 
    colors[ImGuiCol_CheckMark]             = ImVec4(0.61f, 0.00f, 1.00f, 1.00f); 
    colors[ImGuiCol_SliderGrab]            = ImVec4(0.00f, 0.94f, 1.00f, 1.00f); 
    colors[ImGuiCol_Button]                = ImVec4(0.10f, 0.10f, 0.15f, 1.00f);
    colors[ImGuiCol_ButtonHovered]         = ImVec4(0.61f, 0.00f, 1.00f, 1.00f); 
    colors[ImGuiCol_ButtonActive]          = ImVec4(0.00f, 0.94f, 1.00f, 1.00f); 
    colors[ImGuiCol_Tab]                   = ImVec4(0.08f, 0.08f, 0.12f, 1.00f);
    colors[ImGuiCol_TabHovered]            = ImVec4(0.61f, 0.00f, 1.00f, 1.00f);
    colors[ImGuiCol_TabActive]             = ImVec4(0.15f, 0.15f, 0.25f, 1.00f);
}

void DrawMenu() {
    if (!menuVisible) return;
    SetupPremiumStyle();

    ImGuiIO& io = ImGui::GetIO();
    char fps[32]; sprintf(fps, "FPS: %.0f", io.Framerate);
    ImGui::GetForegroundDrawList()->AddText(ImVec2(20, 20), IM_COL32(0, 240, 255, 150), "KZIN VIP SYSTEM");
    ImGui::GetForegroundDrawList()->AddText(ImVec2(20, 40), IM_COL32(100, 100, 100, 150), fps);

    ImGui::SetNextWindowSize(ImVec2(420, 450), ImGuiCond_FirstUseEver);
    ImGui::Begin("KZIN CLIENT | PRIVATE", nullptr, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize);
    
    ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.00f, 0.94f, 1.0f, 1.0f)); 
    ImGui::Text("KZIN CLIENT"); 
    ImGui::PopStyleColor();
    ImGui::SameLine();
    
    // Show Expiry
    ImGui::TextColored(ImVec4(0.8f, 0.8f, 0.8f, 1.0f), "| Expiry: %s", GetExpiryDate().c_str());
    ImGui::Separator();
    ImGui::Spacing();

    if (ImGui::BeginTabBar("PremiumTabs", ImGuiTabBarFlags_None)) {
        if (ImGui::BeginTabItem("Combat")) {
            ImGui::Spacing();
            ImGui::Checkbox("Silent Aim (Triggerbot)", &silentAim);
            ImGui::Checkbox("Drag Headshot", &dragHeadshot);
            if (silentAim || dragHeadshot) {
                ImGui::SliderFloat("FOV Radius", &aimFov, 50.0f, 500.0f, "%.0f px");
            }
            ImGui::EndTabItem();
        }
        
        if (ImGui::BeginTabItem("Visuals")) {
            ImGui::Spacing();
            ImGui::Checkbox("ESP Box", &espBox);
            ImGui::Checkbox("Snapline", &espLine);
            ImGui::Checkbox("Player Name", &espName);
            ImGui::Checkbox("Health Bar", &espHealth);
            ImGui::Checkbox("Distance", &espDistance);
            ImGui::EndTabItem();
        }
        
        if (ImGui::BeginTabItem("System")) {
            ImGui::Spacing();
            if (ImGui::Button("Hide Menu", ImVec2(-1, 40))) menuVisible = false;
            ImGui::Spacing();
            ImGui::TextColored(ImVec4(0.00f, 0.94f, 1.00f, 1.00f), "Telegram: t.me/Kzin_Madhu");
            ImGui::EndTabItem();
        }
        ImGui::EndTabBar();
    }
    ImGui::End();
}

__attribute__((constructor)) void lib_main() {
    pthread_t pt;
    pthread_create(&pt, nullptr, hackThread, nullptr);
}