#pragma once
#include <cstdint>

namespace Offsets {
    constexpr uintptr_t GameFacade        = 0xAD68E18;
    constexpr uintptr_t GameFacade_P2     = 0xB8;
    constexpr uintptr_t BaseGame_Match    = 0x90;
    constexpr uintptr_t Match_PlayerDict  = 0xC0;
    constexpr uintptr_t Match_LocalPlayer = 0xD8;
    constexpr uintptr_t Dict_Entries      = 0x18;
    constexpr uintptr_t Dict_Count        = 0x20;
    constexpr uintptr_t Dict_EntryStride  = 0x18;
    constexpr uintptr_t Dict_EntryValue   = 0x10;
    constexpr uintptr_t Player_HeadTF     = 0x6A8;
    constexpr uintptr_t Player_Camera     = 0x30;
    constexpr uintptr_t Player_HP         = 0x18;
    constexpr uintptr_t Player_IsDead     = 0x7C;
    constexpr uintptr_t Camera_Matrix     = 0x100;
}