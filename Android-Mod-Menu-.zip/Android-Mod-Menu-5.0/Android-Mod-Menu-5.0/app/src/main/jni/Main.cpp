#include <jni.h>
#include <unistd.h>
#include <pthread.h>
#include <cmath>
#include "Includes/Logger.h"
#include "Includes/KittyMemory/MemoryPatch.h"
#include "Menu/Menu.h"
#include "offsets.h"

// Include OpenGL for Image Loading & stb_image for PNGs
#include <GLES2/gl2.h>
#define STB_IMAGE_IMPLEMENTATION
#include "Includes/stb_image.h" 

// --- MATH ---
struct Vector2 { float x, y; };
struct Vector3 { float x, y, z; };
struct Matrix4x4 { float m[4][4]; };

// --- FEATURES ---
bool espBox = false;
bool aimbot = false;
bool drawFov = true;
float aimFov = 150.0f;
bool menuVisible = true; 
GLuint logoTexture = 0; // Holds our logo image

uintptr_t libBase = 0;
int screenWidth = 1080;  
int screenHeight = 2400; 

// --- SAFE READ ---
template <typename T>
T Read(uintptr_t address) {
    if (address < 0x1000) return T{};
    return *reinterpret_cast<T*>(address);
}

// --- WORLD TO SCREEN ---
bool WorldToScreen(Vector3 pos, Vector2* screen, Matrix4x4 matrix) {
    float w = matrix.m[3][0] * pos.x + matrix.m[3][1] * pos.y + matrix.m[3][2] * pos.z + matrix.m[3][3];
    if (w < 0.01f) return false;
    float x = matrix.m[0][0] * pos.x + matrix.m[0][1] * pos.y + matrix.m[0][2] * pos.z + matrix.m[0][3];
    float y = matrix.m[1][0] * pos.x + matrix.m[1][1] * pos.y + matrix.m[1][2] * pos.z + matrix.m[1][3];
    screen->x = (screenWidth / 2.0f) + (screenWidth / 2.0f) * (x / w);
    screen->y = (screenHeight / 2.0f) - (screenHeight / 2.0f) * (y / w);
    return true;
}

// --- HACK LOOP ---
void* hackThread(void*) {
    ProcMap il2cppMap;
    do {
        il2cppMap = KittyMemory::getLibraryMap("libil2cpp.so");
        sleep(1);
    } while (!il2cppMap.isValid());
    libBase = il2cppMap.startAddress;

    while (true) {
        if (espBox || aimbot) {
            uintptr_t gameFacade = libBase + Offsets::GameFacade;
            uintptr_t facadeP2 = Read<uintptr_t>(gameFacade + Offsets::GameFacade_P2);
            uintptr_t match = Read<uintptr_t>(facadeP2 + Offsets::BaseGame_Match);
            
            if (match != 0) {
                uintptr_t localPlayer = Read<uintptr_t>(match + Offsets::Match_LocalPlayer);
                if (localPlayer != 0) {
                    uintptr_t localCamera = Read<uintptr_t>(localPlayer + Offsets::Player_Camera);
                    if (localCamera != 0) {
                        Matrix4x4 viewMatrix = Read<Matrix4x4>(localCamera + Offsets::Camera_Matrix);
                        uintptr_t playerDict = Read<uintptr_t>(match + Offsets::Match_PlayerDict);

                        if (playerDict != 0) {
                            uintptr_t entries = Read<uintptr_t>(playerDict + Offsets::Dict_Entries);
                            int count = Read<int>(playerDict + Offsets::Dict_Count);

                            if (entries != 0 && count > 0 && count < 50) {
                                for (int i = 0; i < count; i++) {
                                    uintptr_t entry = entries + (i * Offsets::Dict_EntryStride);
                                    uintptr_t player = Read<uintptr_t>(entry + Offsets::Dict_EntryValue);

                                    if (player != 0 && player != localPlayer) {
                                        bool isDead = Read<bool>(player + Offsets::Player_IsDead);
                                        float hp = Read<float>(player + Offsets::Player_HP);

                                        if (!isDead && hp > 0) {
                                            uintptr_t headTF = Read<uintptr_t>(player + Offsets::Player_HeadTF);
                                            if (headTF != 0) {
                                                Vector3 headPos = Read<Vector3>(headTF + 0x38); 
                                                Vector2 screenHead;
                                                if (WorldToScreen(headPos, &screenHead, viewMatrix)) {
                                                    // ESP BOX
                                                    if (espBox) {
                                                        ImGui::GetBackgroundDrawList()->AddRect(
                                                            ImVec2(screenHead.x - 40, screenHead.y - 40),
                                                            ImVec2(screenHead.x + 40, screenHead.y + 80),
                                                            IM_COL32(0, 240, 255, 255), 0, 0, 2.0f);
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            // FOV CIRCLE
            if (aimbot && drawFov) {
                ImGuiIO& io = ImGui::GetIO();
                ImGui::GetBackgroundDrawList()->AddCircle(ImVec2(io.DisplaySize.x / 2, io.DisplaySize.y / 2), aimFov, IM_COL32(157, 0, 255, 255), 100, 2.0f);
            }
        }
        usleep(30000); 
    }
    return nullptr;
}

// --- UI & MENU LOADER ---
GLuint LoadTextureFromFile(const char* filename) {
    int width, height, channels;
    unsigned char* data = stbi_load(filename, &width, &height, &channels, 4);
    if (!data) return 0;
    GLuint texture;
    glGenTextures(1, &texture);
    glBindTexture(GL_TEXTURE_2D, texture);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, data);
    stbi_image_free(data);
    return texture;
}

void DrawMenu() {
    if (!menuVisible) return;

    // Load Logo once
    if (logoTexture == 0) {
        logoTexture = LoadTextureFromFile("/sdcard/kzin_logo.png");
    }

    ImGuiStyle& style = ImGui::GetStyle();
    style.WindowRounding = 12.0f;
    style.FrameRounding = 6.0f;
    style.Colors[ImGuiCol_WindowBg] = ImVec4(0.04f, 0.04f, 0.04f, 0.95f); 
    style.Colors[ImGuiCol_CheckMark] = ImVec4(0.00f, 0.94f, 1.00f, 1.00f); 
    style.Colors[ImGuiCol_TitleBgActive] = ImVec4(0.61f, 0.00f, 1.00f, 1.00f); 

    ImGui::Begin("KZIN CLIENT | FF MAX", nullptr, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_AlwaysAutoResize);
    
    // --- DRAW LOGO ---
    if (logoTexture != 0) {
        ImGui::Image((void*)(intptr_t)logoTexture, ImVec2(250, 80)); // Adjust size if your logo is different
    } else {
        ImGui::TextColored(ImVec4(0.00f, 0.94f, 1.00f, 1.00f), "KZIN CLIENT");
    }
    
    ImGui::Separator();

    // --- TABS SYSTEM ---
    if (ImGui::BeginTabBar("##Tabs")) {
        
        // TAB 1: ESP & VISUALS
        if (ImGui::BeginTabItem("Visuals")) {
            ImGui::Spacing();
            ImGui::Checkbox("Enable ESP Box", &espBox);
            ImGui::Spacing();
            // Example of a button inside the tab
            if (ImGui::Button("Reset ESP Colors")) {
                // Code to reset colors if you had them
            }
            ImGui::EndTabItem();
        }

        // TAB 2: AIMBOT
        if (ImGui::BeginTabItem("Aimbot")) {
            ImGui::Spacing();
            ImGui::Checkbox("Enable Aimbot", &aimbot);
            if (aimbot) {
                ImGui::SliderFloat("FOV Radius", &aimFov, 50.0f, 500.0f);
                ImGui::Checkbox("Show FOV Circle", &drawFov);
            }
            ImGui::EndTabItem();
        }

        // TAB 3: SETTINGS / MISC
        if (ImGui::BeginTabItem("Misc")) {
            ImGui::Spacing();
            ImGui::Text("Menu Settings");
            if (ImGui::Button("Hide Menu", ImVec2(150, 30))) {
                menuVisible = false;
            }
            ImGui::EndTabItem();
        }
        
        ImGui::EndTabBar();
    }

    ImGui::End();
}

__attribute__((constructor)) void lib_main() {
    pthread_t pt;
    pthread_create(&pt, nullptr, hackThread, nullptr);
}